#!/usr/bin/env python3
"""Tests for ExecutionContext session identity requirements."""

import asyncio
from pathlib import Path
from types import SimpleNamespace

import pytest

from scribe_mcp.bridges.manifest import BridgeManifest
from scribe_mcp.config.paths import templates_dir
from scribe_mcp.shared.execution_context import RouterContextManager
from scribe_mcp.shared.tool_runtime import execute_tool_call
from scribe_mcp.template_engine import Jinja2TemplateEngine


@pytest.mark.asyncio
async def test_execution_context_requires_session_id():
    router = RouterContextManager()
    payload = {
        "repo_root": "/tmp/repo",
        "mode": "project",
        "intent": "tool:test",
        "affected_dev_projects": [],
    }
    with pytest.raises(ValueError, match="transport_session_id or session_id"):
        await router.build_execution_context(payload)


@pytest.mark.asyncio
async def test_execution_context_transport_session_id_is_stable():
    router = RouterContextManager()
    payload = {
        "repo_root": "/tmp/repo",
        "mode": "project",
        "intent": "tool:test",
        "affected_dev_projects": [],
        "transport_session_id": "conn-1",
    }
    first = await router.build_execution_context(payload)
    second = await router.build_execution_context(payload)
    assert first.session_id == second.session_id
    assert first.transport_session_id == "conn-1"


@pytest.mark.asyncio
async def test_execution_context_accepts_explicit_session_id():
    router = RouterContextManager()
    payload = {
        "repo_root": "/tmp/repo",
        "mode": "project",
        "intent": "tool:test",
        "affected_dev_projects": [],
        "session_id": "session-explicit",
    }
    ctx = await router.build_execution_context(payload)
    assert ctx.session_id == "session-explicit"


class _DummyRuntimeRouter:
    _process_instance_id = "proc-test"

    async def get_or_create_session_id(self, _transport_session_id: str) -> str:
        return "session-1"

    async def build_execution_context(self, payload):
        return SimpleNamespace(mode=payload.get("mode", "project"), stable_session_id="stable-1")

    def set_current(self, _exec_context):
        return "token-1"

    def reset(self, _token):
        return None

    async def get_cached_project(self, _stable_session_id: str):
        return "cached-project"


class _DummyState:
    @staticmethod
    def get_session_mode(_session_id: str):
        return None


class _DummyStateManager:
    async def load(self):
        return _DummyState()


@pytest.mark.asyncio
async def test_execute_tool_call_does_not_inject_project_to_set_project():
    def set_project_stub(agent: str, name: str, root: str) -> dict[str, str]:
        return {"agent": agent, "name": name, "root": root}

    result = await execute_tool_call(
        name="set_project",
        arguments={"agent": "codex", "name": "demo", "root": "/tmp/demo"},
        kwargs={},
        registry={"set_project": set_project_stub},
        app=SimpleNamespace(request_context=None),
        storage_backend=None,
        settings=SimpleNamespace(project_root=Path("/tmp")),
        state_manager=_DummyStateManager(),
        router_context_manager=_DummyRuntimeRouter(),
        sentinel_only=set(),
        sentinel_allowed={"set_project"},
        log_scope_violation_cb=lambda *_args, **_kwargs: None,
    )

    assert result == {"agent": "codex", "name": "demo", "root": "/tmp/demo"}


@pytest.mark.asyncio
async def test_execute_tool_call_injects_project_for_project_aware_tool():
    def read_recent_stub(agent: str, project: str | None = None) -> str | None:
        return project

    result = await execute_tool_call(
        name="read_recent",
        arguments={"agent": "codex"},
        kwargs={},
        registry={"read_recent": read_recent_stub},
        app=SimpleNamespace(request_context=None),
        storage_backend=None,
        settings=SimpleNamespace(project_root=Path("/tmp")),
        state_manager=_DummyStateManager(),
        router_context_manager=_DummyRuntimeRouter(),
        sentinel_only=set(),
        sentinel_allowed={"read_recent"},
        log_scope_violation_cb=lambda *_args, **_kwargs: None,
    )

    assert result == "cached-project"


def test_templates_dir_contains_builtin_documents():
    root = templates_dir()
    assert root.exists()
    assert (root / "documents" / "ARCHITECTURE_GUIDE_TEMPLATE.md").exists()


def test_template_engine_can_validate_builtin_document_templates():
    engine = Jinja2TemplateEngine(project_root=Path("/tmp"), project_name="template-probe")
    validation = engine.validate_template("documents/ARCHITECTURE_GUIDE_TEMPLATE.md")
    assert validation["valid"], validation


def test_bridge_manifest_hooks_support_keyed_config_without_hook_name_field():
    manifest = BridgeManifest.from_dict(
        {
            "bridge_id": "example_bridge",
            "name": "Example Bridge",
            "version": "1.0.0",
            "description": "Bridge",
            "author": "Scribe Team",
            "hooks": {
                "pre_append": {"callback_type": "async", "timeout_ms": 5000, "critical": False},
                "post_append": {"callback_type": "async", "timeout_ms": 5000, "critical": False},
            },
        }
    )

    assert manifest.hooks["pre_append"].hook_name == "pre_append"
    assert manifest.hooks["post_append"].hook_name == "post_append"
    assert manifest.validate() == []


def test_bridge_manifest_hooks_preserve_explicit_hook_name_override():
    manifest = BridgeManifest.from_dict(
        {
            "bridge_id": "bridge_test",
            "name": "Bridge Test",
            "version": "1.0.0",
            "description": "Bridge",
            "author": "Scribe Team",
            "hooks": {
                "pre_append": {
                    "hook_name": "pre_append_custom",
                    "callback_type": "async",
                    "timeout_ms": 5000,
                    "critical": False,
                }
            },
        }
    )

    assert manifest.hooks["pre_append"].hook_name == "pre_append_custom"


@pytest.mark.asyncio
async def test_background_service_status_tracks_success():
    from scribe_mcp import server as server_module

    server_module._background_services.clear()

    async def _work() -> None:
        await asyncio.sleep(0)

    task = server_module.schedule_background_task(
        _work(),
        service_name="unit_success",
        description="unit test successful task",
    )
    await task

    status = server_module.get_background_service_status()["unit_success"]
    assert status["status"] == "healthy"
    assert status["last_error"] is None
    assert status["last_duration_ms"] is not None


@pytest.mark.asyncio
async def test_background_service_status_tracks_failure():
    from scribe_mcp import server as server_module

    server_module._background_services.clear()

    async def _work() -> None:
        await asyncio.sleep(0)
        raise RuntimeError("unit boom")

    task = server_module.schedule_background_task(
        _work(),
        service_name="unit_failure",
        description="unit test failing task",
    )
    with pytest.raises(RuntimeError, match="unit boom"):
        await task

    status = server_module.get_background_service_status()["unit_failure"]
    assert status["status"] == "failed"
    assert "unit boom" in (status["last_error"] or "")
